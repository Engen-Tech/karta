# AGENTS.md — karta bench testbed

Pure stdlib Python. No dependencies, no build step, no network.

- Source lives in `src/`, tests in `tests/`. Tests import via `from src... import`.
- Floor (lint/typecheck do not exist here — the test run is the whole floor):
  `python3 -m unittest discover -s tests -t .`
- Keep every addition small; this repo exists to be measured, not to grow.
