"""Greeting helpers for the karta bench testbed."""


def greet(name: str) -> str:
    """Return a greeting for `name`."""
    return f"Hello, {name}!"
