# karta bench testbed (fixture-v1)

A deliberately tiny Python repo whose only job is to be delivered by karta under
a stopwatch. It is the fixed denominator of the `perf-fixture-cost-baseline`
benchmark vector: the same bytes, the same binder, every quarter, so a change in
per-phase cost is a change in karta and not in the repo.

- `src/greet.py`, `tests/test_greet.py` — the whole pre-existing product.
- `.karta/binders/bench.json` — the two work items a measured run delivers.

Floor: `python3 -m unittest discover -s tests -t .`
